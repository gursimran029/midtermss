/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midterm;

/**
 *
 * @author gursi
 */
public class PurchasedMovie
{
    public boolean active;
    public String _name;
    public int _daysRented;
    public int priceCode;
 
public boolean isActive( ) {
    return active;
}

public PurchasedMovie( String name , int daysRented) {
_name = name;
_daysRented = daysRented;
}

public int priceCode() {
return priceCode;
}


}
