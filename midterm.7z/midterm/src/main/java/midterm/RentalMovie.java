/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midterm;

/**
 *
 * @author gursi
 */
public class RentalMovie  {
 public String _name;
 public int _daysRented;
 public String  tape;
 public int priceCode;

public int daysRented() {
return _daysRented;
}

public RentalMovie(String name, int daysRented) {
_name = tape;
_daysRented = daysRented;
}

public int priceCode() {
return priceCode;
}



}