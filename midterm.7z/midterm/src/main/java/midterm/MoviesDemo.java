/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midterm;

/**
 *
 * @author gursi
 */
public class MoviesDemo {
    


public static void main( String args [ ] ) {
            Movie mov = new Movie();
        System.out.println(mov.PurchasedMovie());
        System.out.println(mov.RentalMovie());
    

} 
}